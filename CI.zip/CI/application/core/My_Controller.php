<?php
	class My_Controller extends CI_Controller{
		public function __construct(){
			parent::__construct();
			//echo "aaa";
			//登陆验证
			//权限验证 
		}
	}

?>