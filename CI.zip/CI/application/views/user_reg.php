<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<script >
$(".")
</script>
<body>
	<!--<form action="check" method="post">
		用户名：<input type="text" name="user"/>
		密码：	<input type="password" name="password"/>
			  	<input type="submit" name="提交"/>
	</form>-->
	<tr>
		<td id='a'>dkhe<button><i class="icon-remove" style="red bigger-140"></i></button></td>
	</tr>
</body>
</html>
<tr>
<td id = 'a'>dkhe</td>
</tr>