<?php
/**
 * <?php
 * 示例
 * require_once("pager.class.php");
 * $subPages = new pager($totalPage,$currentPage);
 * echo $subPages->showpager();
 * ?>
 */
class pager{
	var $each_disNums;//每页显示的条目数
	var $nums;//总条目数
	var $current_page;//当前被选中的页
	var $sub_pages;//每次显示的页数
	var $pageNums;//总页数
	var $page_array = array();//用来构造分页的数组
	var $subPage_link;//每个分页的链接
	var $subPage_type;//显示分页的类型
	var $_lang = array(
		'index_page' => '首页',
		'pre_page' => '上一页',
		'next_page' => '下一页'，
		'last_page' => '尾页',
		'current_page' => '当前页',
		'total_page' => '总页数',
		'current_show' => '当前显示',
		'total_record' => '总记录数：'
   	);

   function __construct($total_page,$current_page,
   	$sub_pages=10,$subPage_link='',$subPage_type=2){
   	$this->pager($total_page,$current_page,$sub_pages,$subPage_link,$subPage_type);
   }; 

   function pager($total_page,$current_page,$sub_pages=10,$subPage_link='',$subPage_type=2){
   	if(!$current_page){
   		$this->current_page=1;
   	}else{
   		$this->current_page = intval($current_page);
   	}
   	$this->sub_pages= intval($current_page);
   	$this->pageNums=ceil($total_page);
   	if($subPage_link){
   		if(strpos($subPage_link,'?page=')===false AND strpos($subPage_link,'&page=')===false){
   			$subPage_link.=(strpos($subPage_link, '?')) === false ?'?':'&').'page=';   			
   			}
   		}


   	}

   		
}

}
?>